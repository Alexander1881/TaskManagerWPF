﻿using System.Windows.Controls;
using System.Windows;
using System.Diagnostics;
using System.Windows.Input;

namespace ElliotTaskManager.Controls
{
    public partial class ProcessPriorityButton : TextBlock
    {
        public ProcessPriorityButton()
        {
            MouseDown += new MouseButtonEventHandler(ProcessPriorityButton_MouseDown);
        }

        void ProcessPriorityButton_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            ParentSwitcher.Priority = (sender as ProcessPriorityButton).PriorityMeaning;
            ParentSwitcher.RefreshButtons();
        }

        public static readonly DependencyProperty _priorityMeaning = //Значение приоритета
                DependencyProperty.Register("PriorityMeaning",
                typeof(ProcessPriorityClass), typeof(ProcessPriorityButton));
        
        public ProcessPriorityClass PriorityMeaning
        {
            get { return (ProcessPriorityClass)GetValue(_priorityMeaning); }
            set { SetValue(_priorityMeaning, value); }
        }

        public static readonly DependencyProperty _parentSwitcher = //Свитчер, в котором находится кнопка
                DependencyProperty.Register("ParentSwitcher",
                typeof(ProcessPrioritySwitcher), typeof(ProcessPriorityButton));

        public ProcessPrioritySwitcher ParentSwitcher
        {
            get { return (ProcessPrioritySwitcher)GetValue(_parentSwitcher); }
            set { SetValue(_parentSwitcher, value); }
        }
    }
}
