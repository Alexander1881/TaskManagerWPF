﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Diagnostics;

namespace ElliotTaskManager.Controls
{
    /// <summary>
    /// Логика взаимодействия для ProcessPrioritySwitcher.xaml
    /// </summary>
    public partial class ProcessPrioritySwitcher : UserControl
    {
        public static readonly DependencyProperty _priority = 
            DependencyProperty.Register(
            "Priority", typeof(ProcessPriorityClass), typeof(ProcessPrioritySwitcher));

        public event EventHandler OnPriorityChanged;

        public ProcessPrioritySwitcher()
        {
            InitializeComponent();
        }

        public void RefreshButtons()
        {
            foreach (UIElement elem in PriorityButtonsGrid.Children)
            {
                if (elem is ProcessPriorityButton)
                {
                    ProcessPriorityButton current = elem as ProcessPriorityButton;
                    if (current.PriorityMeaning == Priority)
                    {
                        current.FontWeight = FontWeights.Bold;
                        current.FontSize = 10;
                    }
                    else
                    {
                        current.FontWeight = FontWeights.Normal;
                        current.FontSize = 9;
                    }
                }
            }
        }

        public ProcessPriorityClass Priority
        {
            get { return (ProcessPriorityClass)GetValue(_priority); }
            set
            {
                SetValue(_priority, value);
                RefreshButtons();
                if (OnPriorityChanged != null)
                {
                    OnPriorityChanged.Invoke(this, null);
                }
            }
        }
    }
}
