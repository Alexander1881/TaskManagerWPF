﻿using System;
using System.Diagnostics;
using System.Management;
using System.Drawing;
using System.Windows;
using System.ComponentModel;
using System.Collections.ObjectModel;
using Timers = System.Timers;
using System.Windows.Media.Imaging;
using System.IO;

namespace ElliotTaskManager
{
    public class ProcessEntity : INotifyPropertyChanged
    {
        #region Параметры процесса
        private Process _process; //Процесс
        private Boolean _canUserAccess; //Может ли пользователь менять процесс
        #endregion Параметры процесса
        #region Отслеживание производительности
        private readonly PerformanceCounter _cpuLoadCounter; //Отслеживает загрузку ЦП
        private readonly PerformanceCounter _memUsageCounter;
        private float _cpuLoadPercentage; //Загрузка ЦП
        private float _memoryMBytesUsage; //Использование памяти в байтах
        #endregion Отслеживание производительности

        public ProcessEntity(UInt32 identity, Boolean canUserAccess)
        {
            _process = Process.GetProcessById(Convert.ToInt32(identity)); //Процесс
            _canUserAccess = canUserAccess; //Может ли пользователь менять
            //Производительность
            _cpuLoadCounter =
                new PerformanceCounter("Process", "% Processor Time", _process.ProcessName, true);
            _memUsageCounter =
                new PerformanceCounter("Process", "Working Set", _process.ProcessName, true);
        }
        public BitmapImage IconSource
        {
            get 
            {
                BitmapImage bImg = new BitmapImage();
                try
                {
                    Icon procIco = Icon.ExtractAssociatedIcon(_process.MainModule.FileName);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        Bitmap dImg = procIco.ToBitmap();
                        dImg.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                        bImg.BeginInit();
                        bImg.StreamSource = new MemoryStream(ms.ToArray());
                        bImg.EndInit();
                    }
                }
                catch
                {
                }
                return bImg;
            }
        }
        
        public Process Process
        {
            get { return _process; }
        }

        public Boolean CanUserAccess
        {
            get { return _canUserAccess; }
        }

        public PerformanceCounter CpuLoadCounter
        {
            get { return _cpuLoadCounter; }
        }

        public PerformanceCounter MemUsageCounter
        {
            get { return _memUsageCounter; }
        }

        public float MemoryMBytesUsage
        {
            set { _memoryMBytesUsage = value; OnPropertyChanged("MemoryMBytesUsage"); }
            get { return _memoryMBytesUsage; }
        }

        public float CpuLoadPercentage
        {
            set { _cpuLoadPercentage = value; OnPropertyChanged("CpuLoadPercentage"); }
            get { return _cpuLoadPercentage; }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
    }

    class WMIProcessRepository : INotifyPropertyChanged
    {
        //Имя пользователя
        private static String _userName = Environment.UserName;
        private static String _domainName = Environment.UserDomainName;
        //Процессы
        private ObservableCollection<ProcessEntity> _processEntitiesCollection;

        public ObservableCollection<ProcessEntity> ProcessEntitiesCollection
        {
            set { _processEntitiesCollection = value; }
            get { return _processEntitiesCollection; }
        }

        public WMIProcessRepository()
        {
            InitializeAllAndBeginTracking();
        }

        //Инициализация списка процессов
        public void InitializeAllAndBeginTracking()
        {
            _processEntitiesCollection = new ObservableCollection<ProcessEntity>();
            ObjectQuery processQueryObject = new ObjectQuery();
            ManagementObjectSearcher processSearcher = new ManagementObjectSearcher();
            ManagementObjectCollection foundProcessesList;
            processQueryObject.QueryString = "Select * From Win32_Process"; //Строка запроса для обьекта
            processSearcher.Query = processQueryObject; //Обьект запроса
            foundProcessesList = processSearcher.Get(); //Выполнение запроса
            foreach (ManagementObject managementObject in foundProcessesList)
            {
                UInt32 processId = (UInt32)managementObject.Properties["ProcessId"].Value;
                if (processId == 0 || processId == 4) continue; //System Idle не является реальным процессом
                //Массив из двух строк, в который запишутся домен и владелец
                String[] processOwner = {"username", "domain"}; 
                managementObject.InvokeMethod("GetOwner", processOwner); //Владелец
                Boolean canUserAccess = //Пользователь имеет доступ только к своим (не системным) процессам
                    processOwner[0] == _userName && processOwner[1] == _domainName;
                //Добавление процесса в коллекцию
                _processEntitiesCollection.Add(new ProcessEntity(processId, canUserAccess));
            }
            //Отслеживание изменений процессов (появился новый \ пропал из имеющихся)
            PeriodicScanForNewAndGhostProcesses();

            //Периодическое обновления показателей использования ЦП и памяти
            Timers.Timer updateProcessParamsTimer = new Timers.Timer(); //Таймер обновления
            updateProcessParamsTimer.Elapsed +=
                (sender, eventArgs) => RefreshProcessesData(sender, eventArgs);
            updateProcessParamsTimer.Interval = 1000;
            updateProcessParamsTimer.Enabled = true;
            updateProcessParamsTimer.Start();
        }
        //Обновление процента использования ЦП и памяти. Выполняется в отдельном потоке
        public void RefreshProcessesData(object sender, EventArgs timerArguments)
        {
            //Пока данные процесса обновляются, нельзя его удалять\менять приоритет и так далее
            lock (_processEntitiesCollection) 
            {
                foreach (ProcessEntity processEntity in _processEntitiesCollection)
                {
                    processEntity.CpuLoadPercentage = //Использование ЦП
                        (float)Math.Round(processEntity.CpuLoadCounter.NextValue(), 2);
                    processEntity.MemoryMBytesUsage = //Использование ОП
                        (float)Math.Round(processEntity.MemUsageCounter.NextValue() / 1024 / 1024, 2);
                }
            }
        }
        //Отслеживает через WMI события появления и исчезновения процессов каждые полсекунды
        public void PeriodicScanForNewAndGhostProcesses()
        {
            TimeSpan updateInterval = new TimeSpan(0, 0, 0, 0, 500);
            String targetInstanceDescription = "TargetInstance isa \"Win32_Process\"";
            //Отслеживание запуска
            WqlEventQuery instanceCreationMonitorQuery = //Запрос на WMI-событие создания процесса
                new WqlEventQuery("__InstanceCreationEvent", updateInterval, targetInstanceDescription);
            ManagementEventWatcher instanceCreationWatcher = new ManagementEventWatcher();
            instanceCreationWatcher.Query = instanceCreationMonitorQuery;
            instanceCreationWatcher.EventArrived += new EventArrivedEventHandler(ProcessStartEvent);
          //  instanceCreationWatcher.Start();
            //Отслеживание закрытия
            WqlEventQuery instanceDeletionQuery =
                new WqlEventQuery("__InstanceDeletionEvent", updateInterval, targetInstanceDescription);
            ManagementEventWatcher instanceDeletionWatcher = new ManagementEventWatcher();
            instanceDeletionWatcher.Query = instanceDeletionQuery;
            instanceDeletionWatcher.EventArrived += new EventArrivedEventHandler(ProcessEndEvent);
        //    instanceDeletionWatcher.Start();
            
        }
        //Реакция на появление процесса
        public void ProcessStartEvent(object sender, EventArrivedEventArgs e)
        {
            ManagementBaseObject newEvent = e.NewEvent;
            ManagementBaseObject targetInstanceBase = (ManagementBaseObject)newEvent["TargetInstance"];

            UInt32 processId = (UInt32)targetInstanceBase.Properties["ProcessId"].Value;
            //newEvent.

            ObjectQuery processQueryObject = new ObjectQuery();
            ManagementObjectSearcher processSearcher = new ManagementObjectSearcher();
            ManagementObjectCollection foundProcessesList;
            processQueryObject.QueryString = //Строка запроса для обьекта
                "Select * From Win32_Process WHERE ProcessId = " + processId; 
            processSearcher.Query = processQueryObject; //Обьект запроса
            foundProcessesList = processSearcher.Get(); //Выполнение запроса
            foreach (ManagementObject managementObject in foundProcessesList)
            {
                //Массив из двух строк, в который запишутся домен и владелец
                String[] processOwner = { "username", "domain" };
                managementObject.InvokeMethod("GetOwner", processOwner); //Владелец
                Boolean canUserAccess = //Пользователь имеет доступ только к своим (не системным) процессам
                    processOwner[0] == _userName && processOwner[1] == _domainName;
                //Добавление процесса в коллекцию
                lock (_processEntitiesCollection)
                {
                    Application.Current.Dispatcher.BeginInvoke(
                        new Action(() => 
                            _processEntitiesCollection.Add(
                            new ProcessEntity(processId, canUserAccess))));
                }
               
            }
        }
        //Реакция на исчезновение процесса
        public void ProcessEndEvent(object sender, EventArrivedEventArgs e)
        {
            ManagementBaseObject newEvent = e.NewEvent;
            ManagementBaseObject targetInstance = (ManagementBaseObject)newEvent["TargetInstance"];
            UInt32 processId = (UInt32)targetInstance.Properties["ProcessId"].Value;

            lock (_processEntitiesCollection)
            {
                for (UInt16 i = 0; i < _processEntitiesCollection.Count; ++i)
                {
                    if (_processEntitiesCollection[i].Process.Id == processId)
                    {
                        Application.Current.Dispatcher.BeginInvoke(
                            new Action(() => _processEntitiesCollection.Remove(
                                _processEntitiesCollection[i])));
                        break;
                    }
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
    }
}
