﻿using System;
using System.Windows;
using System.Windows.Input;

namespace ElliotTaskManager
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        readonly ICommand _cmdMinimize;
        readonly ICommand _cmdClose;
        readonly ICommand _cmdShow;

        public MainWindow()
        {
            InitializeComponent();
            _cmdMinimize = new CmdMinimizeWindow(this);
            _cmdClose = new CmdCloseWindow(this);
            _cmdShow = new CmdShowWindow(this);
            ViewModel vMdl = new ViewModel();
            viewLayer.DataContext = vMdl;
        }

        void _trayIcon_Click(object sender, EventArgs e)
        {
            if (_cmdShow.CanExecute(null))
            {
                _cmdShow.Execute(null);
            }
        }

        //Перетаскивание окна
        private void rctDraggingRect_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }

        //Развернуть окно
        class CmdShowWindow : ICommand
        {
            MainWindow _wnd;

            public CmdShowWindow(MainWindow wnd)
            {
                _wnd = wnd;
            }

            public bool CanExecute(object parameter)
            {
                return true;
            }

            public event EventHandler CanExecuteChanged
            {
                add { CommandManager.RequerySuggested += value; }
                remove { CommandManager.RequerySuggested -= value; }
            }

            public void Execute(object parameter)
            {
                _wnd.WindowState = WindowState.Normal;
            }
        }

        //Свернуть окно
        class CmdMinimizeWindow : ICommand
        {
            MainWindow _wnd;

            public CmdMinimizeWindow(MainWindow wnd)
            {
                _wnd = wnd;
            }

            public bool CanExecute(object parameter)
            {
                return true;
            }

            public event EventHandler CanExecuteChanged
            {
                add { CommandManager.RequerySuggested += value; }
                remove { CommandManager.RequerySuggested -= value; }
            }

            public void Execute(object parameter)
            {
                _wnd.WindowState = WindowState.Minimized;
            }
        }

        class CmdCloseWindow : ICommand
        {
            MainWindow _wnd;

            public CmdCloseWindow(MainWindow wnd)
            {
                _wnd = wnd;
            }

            public bool CanExecute(object parameter)
            {
                return true;
            }

            public event EventHandler CanExecuteChanged
            {
                add { CommandManager.RequerySuggested += value; }
                remove { CommandManager.RequerySuggested -= value; }
            }

            public void Execute(object parameter)
            {
                _wnd.Close();
            }
        }

        //"Заглушка", вызов команды на клик. В MainWindow лучше сделать именно так
        private void txtblkMinimize_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (_cmdMinimize.CanExecute(null))
            {
                _cmdMinimize.Execute(null);
            }
        }

        private void txtblkClose_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (_cmdClose.CanExecute(null))
            {
                _cmdClose.Execute(null);
            }
        }
    }
}
