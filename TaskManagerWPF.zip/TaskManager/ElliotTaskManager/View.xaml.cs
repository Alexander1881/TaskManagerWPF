﻿using System.Windows.Controls;

namespace ElliotTaskManager
{
    /// <summary>
    /// Логика взаимодействия для View.xaml
    /// </summary>
    public partial class View : UserControl
    {
        public View()
        {
            InitializeComponent();
        }
    }
}
