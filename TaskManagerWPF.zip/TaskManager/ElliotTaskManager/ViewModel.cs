﻿using System;
using System.ComponentModel;
using System.Windows.Input;

namespace ElliotTaskManager
{
    class ViewModel : INotifyPropertyChanged
    {
        private ICommand _processParametersChangeCommand;
        private ProcessEntity _selectedItem;
        private WMIProcessRepository _processRepository = new WMIProcessRepository();

        public ViewModel()
        {
            _processParametersChangeCommand =
                new ProcessParametersChangeCommandImplementation(this);
        }

        public WMIProcessRepository ProcessRepository
        {
            get { return _processRepository; }
        }

        public ICommand ProcessParametersChangeCommand
        {
            get { return _processParametersChangeCommand; }
        }

        class ProcessParametersChangeCommandImplementation : ICommand
        {
            private ViewModel _vMdl;
            public ProcessParametersChangeCommandImplementation(ViewModel vMdl)
            {
                _vMdl = vMdl;
            }

            public bool CanExecute(object parameter)
            {
                if (_vMdl._selectedItem == null) return false;
                return _vMdl._selectedItem.CanUserAccess;
            }

            
            public event EventHandler CanExecuteChanged
            {
                add { CommandManager.RequerySuggested += value; }
                remove { CommandManager.RequerySuggested -= value; }
            }

            public void Execute(object parameter)
            {
                ProcessAccessWindow procAccWnd = new ProcessAccessWindow();
                procAccWnd.Show(_vMdl._processRepository.ProcessEntitiesCollection,
                    _vMdl._selectedItem);
            }
        }

        public ProcessEntity SelectedItem
        {
            get { return _selectedItem; }
            set { _selectedItem = value; }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
    }
}
