﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Collections.ObjectModel;

namespace ElliotTaskManager
{
    public partial class ProcessAccessWindow : Window
    {
        readonly ICommand _cmdClose;
        private ProcessEntity _targetProcess;
        private ObservableCollection<ProcessEntity> _processes;
        public ProcessAccessWindow()
        {
            InitializeComponent();
            _cmdClose = new CmdCloseWindow(this);
        }

        void prioritySwitcher_OnPriorityChanged(object sender, EventArgs e)
        {
            _targetProcess.Process.PriorityClass = 
                prioritySwitcher.Priority;
        }

        public void Show(ObservableCollection<ProcessEntity> processes,
            ProcessEntity targetProcess)
        {
            _processes = processes;
            _targetProcess = targetProcess;
            txtBlockServiceName.Text = _targetProcess.Process.ProcessName;
            prioritySwitcher.Priority = _targetProcess.Process.PriorityClass;
            prioritySwitcher.OnPriorityChanged += 
                new EventHandler(prioritySwitcher_OnPriorityChanged);
            base.Show();
        }

        //Перетаскивание окна
        private void rctDraggingRect_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }
        
        private void txtblkClose_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (_cmdClose.CanExecute(null))
            {
                _cmdClose.Execute(null);
            }
        }

        class CmdCloseWindow : ICommand
        {
            ProcessAccessWindow _wnd;

            public CmdCloseWindow(ProcessAccessWindow wnd)
            {
                _wnd = wnd;
            }

            public bool CanExecute(object parameter)
            {
                return true;
            }

            public event EventHandler CanExecuteChanged
            {
                add { CommandManager.RequerySuggested += value; }
                remove { CommandManager.RequerySuggested -= value; }
            }

            public void Execute(object parameter)
            {

                _wnd.Close();
            }
        }

        private void btnKill_Click(object sender, RoutedEventArgs e)
        {
            lock (_processes)
            {
                _targetProcess.Process.Kill();
                _processes.Remove(_targetProcess);
                Close();
            }
        }
    }
}
